﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Prac_6_Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "EssenceService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select EssenceService.svc or EssenceService.svc.cs at the Solution Explorer and start debugging.
    public class EssenceService : IEssenceService
    {
        EssenceDatabaseDataContext db = new EssenceDatabaseDataContext();

        public Accesory GetAccessoriesID(string ID)
        {
            var FoundAccesory = (from A in db.Accesories
                                 where A.A_ID.Equals(ID)
                                 select A).FirstOrDefault();

            return FoundAccesory;
        }

        public List<Accesory> GetAllAccesories()
        {
            var FA = (from A in db.Accesories
                      select A).ToList();

            return FA;
        }

        public List<Clothing> GetAllClothing()
        {
            var FC = (from A in db.Clothings
                      select A).ToList();

            return FC;
        }

        public List<Shoe> GetAllShoes()
        {
            var FS = (from A in db.Shoes
                      select A).ToList();

            return FS;
        }

        public Clothing GetClothingID(string ID)
        {
            var FoundClothing = (from C in db.Clothings
                                 where C.C_ID.Equals(ID)
                                 select C).FirstOrDefault();
            return FoundClothing;
        }

        public Shoe GetShoeID(string ID)
        {
            var FoundShoe = (from S in db.Shoes
                                 where S.S_ID.Equals(ID)
                                 select S).FirstOrDefault();
            return FoundShoe;
        }
    }
}
