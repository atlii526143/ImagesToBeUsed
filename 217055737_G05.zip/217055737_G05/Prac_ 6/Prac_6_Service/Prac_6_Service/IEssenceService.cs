﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;


namespace Prac_6_Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IEssenceService" in both code and config file together.
    [ServiceContract]
    public interface IEssenceService
    {
        [OperationContract]
        Shoe GetShoeID(string ID);
        [OperationContract]
        List<Shoe> GetAllShoes();

        [OperationContract]
        Clothing GetClothingID(string ID);
        [OperationContract]
        List<Clothing> GetAllClothing();

        [OperationContract]
        Accesory GetAccessoriesID(string ID);
        [OperationContract]
        List<Accesory> GetAllAccesories();
    }
}
